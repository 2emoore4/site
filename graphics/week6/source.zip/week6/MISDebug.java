package week6;

import java.awt.*;
import util.MISApplet;
import util.Moveable;
import util.ZRenderer;

public class MISDebug extends MISApplet {

    double t = 0;
    boolean xMove = true;

    ZRenderer zrenderer;
    Moveable bouncer;

    int[] bgColor = new int[] {255, 255, 255};

    @Override
    public void initialize() {

        zrenderer = new ZRenderer(W, H);
        bouncer = new Moveable();
        bouncer.cube();
        zrenderer.add(bouncer);

        zrenderer.setBGColor(new int[] {167, 219, 216});
        zrenderer.setDrawColor(new int[] {85, 85, 85});

        zrenderer.resetPix();
        zrenderer.renderWorld();
    }
   
    @Override
    public void initFrame(double time) {
        t = 3 * time;

        // zrenderer.resetPix();
        // zrenderer.renderWorld();

        // bouncer.rotateY(0.01);
    }

    @Override
    public void setPixel(int x, int y, int rgb[]) {

        int[] color = zrenderer.getPix(x, y);

        rgb[0] = color[0];
        rgb[1] = color[1];
        rgb[2] = color[2];
    }
}
package util;

public class ZRenderer {

    // TEMPORARY VARIABLES
    double[] tmp3DVertex, tmpDoubleVertex;
    int[] tmp2DVertex, tmpColor, tmpBgColor;
    double[][] tmpProjectedFace;
    double[][][] tmpTriangles, tmpTrapezoids;
    boolean[] positive;

    // TEMPORARY PIXEL ARRAY
    int[][] pix;

    Geometry world;

    int w, h;
    double FL = 10.0;

    public ZRenderer(int w, int h) {

        // INITIALIZE TEMP VARIABLES
        tmp3DVertex = new double[3];
        tmpDoubleVertex = new double[2];
        tmp2DVertex = new int[2];
        tmpProjectedFace = new double[4][2];
        tmpTriangles = new double[2][3][2];
        tmpTrapezoids = new double[4][4][2];

        // HARDCODING THIS ARRAY, FOR NOW, TO PRETEND THAT ALL TRIANGLES ARE POSITIVE
        positive = new boolean[] {true, true};

        this.pix = new int[w * h][3];

        world = new Geometry();
        this.w = w;
        this.h = h;
    }

    // USED BY MISAPPLET TO GET THE RGB FOR A SPECIFIC PIXEL
    public int[] getPix(int x, int y) {
        return pix[x + w * y];
    }

    // RESETS THE PIXEL ARRAY TO THE BACKGROUND COLOR
    public void resetPix() {
        for (int i = 0; i < pix.length; i++) {
            pix[i][0] = tmpBgColor[0];
            pix[i][1] = tmpBgColor[1];
            pix[i][2] = tmpBgColor[2];
        }
    }

    // RENDERS EACH CHILD OF THE 'WORLD' GEOMETRY
    public void renderWorld() {
        for (int i = 0; i < world.getNumChildren(); i++) {
            Geometry child = world.getChild(i);
            child.transformByParent(world);
            renderGeometry(child);
        }
    }

    // RENDERS THE FACES OF A GEOMETRY, THEN RENDERS ITS CHILDREN
    private void renderGeometry(Geometry geo) {

        if (geo instanceof Moveable) {
            Moveable m = (Moveable) geo;
            m.renderPrep();
        }

        if (geo.hasVertex()) {
            processFaces(geo);
        }

        for (int i = 0; i < geo.getNumChildren(); i++) {
            Geometry child = geo.getChild(i);
            child.transformByParent(geo);
            renderGeometry(child);
        }
    }

    // PROJECTS FACES, CONVERTS TO TRIANGLES, CONVERTS TO TRAPEZOIDS, SCANS TRAPEZOIDS
    private void processFaces(Geometry geo) {

        int testFace = 1;

        for (int f = 0 ; f < geo.getNumFaces(); f++) {

            // System.err.println("face #" + f);

            // PROJECT FACES
            for (int v = 0; v < geo.getFace(f).length(); v++) {

                int i = geo.getFace(f).getVertex(v);
                geo.getGlobMatrix().transform(geo.getVertex(i).toArray(), tmp3DVertex);
                projectPoint(tmp3DVertex, tmp2DVertex);

                set2DVertex(tmpProjectedFace[v], (double) tmp2DVertex[0], (double) tmp2DVertex[1]);
            }

            trianglize();
            buildTrapezoids();
            scanTrapezoids();

            // System.err.println();
        }
    }

    // CONVERTS PROJECTED FACES TO TRIANGLES
    private void trianglize() {

        double[] vertexZero = tmpProjectedFace[0];
        double[] vertexOne = tmpProjectedFace[1];
        double[] vertexTwo = tmpProjectedFace[2];
        double[] vertexThree = tmpProjectedFace[3];

        double[][] triangleZero = tmpTriangles[0];
        double[][] triangleOne = tmpTriangles[1];

        copy2DVertex(vertexZero, triangleZero[0]);
        copy2DVertex(vertexTwo, triangleZero[1]);
        copy2DVertex(vertexOne, triangleZero[2]);

        copy2DVertex(vertexZero, triangleOne[0]);
        copy2DVertex(vertexThree, triangleOne[1]);
        copy2DVertex(vertexTwo, triangleOne[2]);

        // if (area(triangleZero) > 0) {
            // System.err.println("t zero is positive");
        //     positive[0] = true;
        // } else {
        //     positive[0] = false;
        // }
        // if (area(triangleOne) > 0) {
        //     System.err.println("t one is positive");
        //     positive[1] = true;
        // } else {
        //     positive[1] = false;
        // }

        sortTriangle(triangleZero);
        sortTriangle(triangleOne);
    }

    // FINDS THE AREA OF A TRIANGLE
    private double area(double[][] triangle) {

        // System.err.println("vertices of this triangle:");
        // for (int i = 0; i < triangle.length; i++) {
        //     System.err.println("v" + i + ": " + triangle[i][0] + "," + triangle[i][1]);
        // }

        double xA = triangle[2][0];
        double xB = triangle[0][0];
        double yA = triangle[2][1];
        double yB = triangle[0][1];

        double a1 = (xA - xB) * (yA + yB) / 2.0;

        xA = triangle[2][0];
        xB = triangle[1][0];
        yA = triangle[2][1];
        yB = triangle[1][1];

        double a2 = (xA - xB) * (yA + yB) / 2.0;

        xA = triangle[1][0];
        xB = triangle[0][0];
        yA = triangle[1][1];
        yB = triangle[0][1];

        double a3 = (xA - xB) * (yA + yB) / 2.0;

        return a1 + a2 - a3;
    }

    // SORTS THE VERTICES OF A TRIANGLE FROM LOW TO HIGH IN THE Y DIRECTION
    private void sortTriangle(double[][] triangle) {

        if (triangle[0][1] > triangle[1][1]) {
            swapVertex(0, 1, triangle);
        }

        if (triangle[1][1] > triangle[2][1]) {
            swapVertex(1, 2, triangle);
        }

        if (triangle[0][1] > triangle[1][1]) {
            swapVertex(0, 1, triangle);
        }
    }

    // HELPER SWAP METHOD
    private void swapVertex(int i, int j, double[][] triangle) {
        tmpDoubleVertex[0] = triangle[i][0];
        tmpDoubleVertex[1] = triangle[i][1];
        copy2DVertex(triangle[j], triangle[i]);
        copy2DVertex(tmpDoubleVertex, triangle[j]);
    }

    // CONVERTS TRIANGLES TO TRAPEZOIDS
    private void buildTrapezoids() {

        for (int i = 0; i < tmpTriangles.length; i++) {

            // ONLY MAKE TRAPEZOIDS IF TRIANGLE HAS POSITIVE AREA
            if (positive[i]) {
                double[] a = tmpTriangles[i][0];
                double[] b = tmpTriangles[i][1];
                double[] c = tmpTriangles[i][2];

                double yA = a[1];
                double yB = b[1];
                double yC = c[1];

                double t = (yB - yA) / (yC - yA);

                double xA = a[0];
                double xB = b[0];
                double xC = c[0];

                double xD = xA + t * (xC - xA);
                double yD = b[1];

                double[][] trapZero = tmpTrapezoids[2 * i];
                double[][] trapOne = tmpTrapezoids[(2 * i) + 1];

                if (xB < xD) {
                    // FIRST SCENARIO
                    set2DVertex(trapZero[0], xA, yA);
                    set2DVertex(trapZero[1], xA, yA);
                    set2DVertex(trapZero[2], xB, yB);
                    set2DVertex(trapZero[3], xD, yD);

                    set2DVertex(trapOne[0], xB, yB);
                    set2DVertex(trapOne[1], xD, yD);
                    set2DVertex(trapOne[2], xC, yC);
                    set2DVertex(trapOne[3], xC, yC);
                } else {
                    // SECOND SCENARIO
                    set2DVertex(trapZero[0], xA, yA);
                    set2DVertex(trapZero[1], xA, yA);
                    set2DVertex(trapZero[2], xD, yD);
                    set2DVertex(trapZero[3], xB, yB);

                    set2DVertex(trapOne[0], xD, yD);
                    set2DVertex(trapOne[1], xB, yB);
                    set2DVertex(trapOne[2], xC, yC);
                    set2DVertex(trapOne[3], xC, yC);
                }
            }
        }
    }

    // SCANS THE TRAPEZOIDS AND SETS THE PIXELS IN THE TEMP PIXEL ARRAY
    private void scanTrapezoids() {

        for (int i = 0; i < tmpTrapezoids.length; i++) {

            // ONLY SCAN TRAPEZOIDS IF TRIANGLE IS POSITIVE
            if (positive[i / 2]) {
                double XLT = tmpTrapezoids[i][0][0];
                double XRT = tmpTrapezoids[i][1][0];
                double XLB = tmpTrapezoids[i][2][0];
                double XRB = tmpTrapezoids[i][3][0];

                double YT = tmpTrapezoids[i][0][1];
                double YB = tmpTrapezoids[i][2][1];

                int YLOW, YHIGH;
                if (YT > YB) {
                    YLOW = (int) YB;
                    YHIGH = (int) YT;
                } else {
                    YLOW = (int) YT;
                    YHIGH = (int) YB;
                }

                // FOR EACH SCANLINE
                for (int y = YLOW; y < YHIGH; y++) {

                    double t = (y - YT) / (YB - YT);
                    double XL = (XLT + t * (XLB - XLT));
                    double XR = (XRT + t * (XRB - XRT));

                    int XLOW, XHIGH;
                    if (XL > XR) {
                        XLOW = (int) XR;
                        XHIGH = (int) XL;
                    } else {
                        XLOW = (int) XL;
                        XHIGH = (int) XR;
                    }

                    for (int x = XLOW; x <= XHIGH; x++) {
                        if ((x >= 0 && x < w) && (y >= 0 && y < h)) {
                            pix[x + w * y][0] = tmpColor[0];
                            pix[x + w * y][1] = tmpColor[1];
                            pix[x + w * y][2] = tmpColor[2];
                        }
                    }
                }
            }
        }
    }

    // KEN PERLIN WROTE THIS
    private void projectPoint(double[] xyz, int[] pxy) {
        double x = xyz[0];
        double y = xyz[1];
        double z = xyz[2];

        pxy[0] = w / 2 + (int)(h * x / (FL - z));
        pxy[1] = h / 2 - (int)(h * y / (FL - z));
    }

    private void copy2DVertex(double[] src, double[] dest) {
        dest[0] = src[0];
        dest[1] = src[1];
    }

    private void set2DVertex(double[] dest, double x, double y) {
        dest[0] = x;
        dest[1] = y;
    }

    public void setFocalLength(double l) {
        this.FL = l;
    }

    public void add(Geometry geo) {
        world.add(geo);
    }

    public void remove(Geometry geo) {
        world.remove(geo);
    }

    public void setBGColor(int[] rgb) {
        this.tmpBgColor = rgb;
    }

    public void setDrawColor(int[] rgb) {
        this.tmpColor = rgb;
    }
}
package util;

public class Vertex {

    double[] coordinates;

    public Vertex() {
        this.coordinates = new double[3];
    }

    public Vertex(double x, double y, double z) {
        this.coordinates = new double[] {x, y, z};
    }

    public void set(int pos, double value) {
        this.coordinates[pos] = value;
    }

    public double[] toArray() {
        return this.coordinates;
    }
}
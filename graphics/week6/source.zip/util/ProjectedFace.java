package util;

public class ProjectedFace {

    Vertex2D[] vertices;

    public ProjectedFace() {
        this.vertices = new Vertex2D[4];

        for (int i = 0; i < vertices.length; i++) {
            vertices[i] = new Vertex2D();
        }
    }

    public Vertex2D getVertex(int index) {
        return vertices[index];
    }

    public void setVertex(int index, int x, int y) {
        vertices[index].setX(x);
        vertices[index].setY(y);
    }
}